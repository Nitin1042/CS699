###################################################

This project Personal Finance Tracker is a tool that can used by anyone to keep track of their finances and make healthy spending habits.

To run the project:

1. Run the app.py program
2. This will make the program to listen on 127.0.0.1:5000
3. You will be greeted with the login page on entering the url
4. Once you login/register you can perform the following actions:
	- View the added expenses so far
	- Add a new expense by clicking on Add Expense button on the home page
	- Delete an expense
	- View the spending report by category by clicking on the Report button
	
###################################################
